var new_lang =   {

"lt0": " Bed Blog ",

"lt1": "SEKS",

"lt2": " LJEPOTA ",

"lt3": " LJUBAV ",

"lt4": "ORGAZAM",

"lt5": "VIDEO",

"lt6": "SEDAM GRIJEHA",

"lt7": " POTENCIJA ",

"lt8": " Griješiš u krevetu?",

"lt10": "12 komentara",

"lt11": "4 556 posjeta ",

"lt12": " Koji od sedam grijeha najbolje opisuje vaš seksualni život? Je li to samo jedan? Ili, možda, sve? Reći ćemo Vam kako ispuniti svoje najtajnije želje...",

"lt13": " Pohlepa ",

"lt14": " Koliko djevojaka trebate za potpuno zadovoljstvo? Jedna? Oh, da, dobro, kao što smo uvjerovali!",

"lt15": " Svaki muškarac sanja o seksu s dvije vruće djevojke, a najmoćniji alfa muškarci uvijek su raspoloženi da provedu noć sa <span class=\"text__accent\">3 ili 4</span>. Mislite li da to možete učiniti? Čitajte ovaj članak do kraja, i promijenite svoje mišljenje",

"lt16": "Požuda ",

"lt17": " Muškarci su lovci po prirodi, uzbuđeni su kad se djevojka odmakne od njih, a teško je uhvatiti.",

"lt18": " Ali jeste li stvarno spremni pričekati dok ona bude spremna ili nešto učiniti <span class=\"text__accent\"> povucite nje u krevet </span> na prvom sastanku?",

"lt19": "Ponos ",

"lt20": " Dovoljno je priznati, sviđa Vam se tijekom seksa,?<span class=\"text__accent\"> kada djevojka vriska uzbuđena </span>, koristi noktiju, a onda svima govori da ste božanski u seksu?!",

"lt21": " Čestitam, ovo je samo jedan od vaših malih grijeha.",

"lt22": " Ljubomora ",

"lt23": 'Svatko gleda porno pa nemojte se pretvarati da ste dobar momak. Što osjećate kada vidite ogromne alate pornog glumca koji <span class = \ "text__accent \"> mogu zadovoljiti </ span> svoje partnere na sati?',

"lt24": " Zavist, naravno. Sigurno to i želite. Vjerujte, to je lakše nego što mislite.",

"lt25": " Gnjev ",

"lt26": 'Kako se osjećate kada <span class = \ "text__accent \"> imate kvarova </ span> u krevetu? Razočarani, uvrijeđeni, ljuti? Pa, izgleda da ste spremni razbiti sve! Ovo je normalno, nitko ne želi biti neuspješen. Najvažnije je riješiti ovaj problem.',

"lt27": " Proždrljivost ",

"lt28": " Svatko ima tajnu seksualnu fantaziju. Jedna od najpopularnijih -<span class=\"text__accent\"> da nahranite svoju djevojku spermom,</span> što više to bolje!",

"lt29": " Baš kao u omiljenim porno filmovima. Djevojke poput ove, vjerujte mi! Jedno pitanje je kako dobiti toliko sperme? Nastavite čitati i naučit ćete.",

"lt30": " Lijenost ",

"lt31": " Muškarci vole kada djevojke preuzmu inicijativu u svojim rukama. Podiže se na vas i uzdiše, kreće se sama, a vi gledate i uživate u procesu.",

"lt32": " Izvrsno, zar ne? Ponekad možeš da budeš lijen.",

"lt33": " Biti grešnik nije tako loše. Pogotovo kad stvarno možete primijeniti ove grijehe u praksi. Kako bi se osiguralo da se sve vaše želje ostvare, trebate samo jedno -<a class=\"link\" href=\"\">XX</a>- proizvod za povećanje penisa i povećanje potencijala.",

"lt34": "Samo za 1 mjesec penis će se povećati za 3-5 cm! Nije loše, zar ne? Ali to nije sve! Ako primijenite XX prije seksa, možete zajebavati SATIMA!",

"lt35": " Nijedna djevojka neće ostati nezadovoljna. Tvoj tvrdi kameni penis će voziti bilo koju ženu ludom!",

"lt36": "Prije",

"lt37": "Posle",

"lt38": " Dakle, požurite narediti <a class=\"link\" href=\"\">XX</a> i pozvati izvrsnu crnku s velikim titsom u svoj dom. Ali nemojte zaboraviti da vam je potrebno dovoljno kondoma, jedan paket je vrlo malo.",

"lt39": "Narediti XX",

"lt40": "KOMENTARI",

"lt41": "Milovan",

"lt43": " Dovraga, volim biti grešnik u krevetu. Prejedanje je moj san. Uvijek sam mislio da sperma u porno filmovima nije prava i kad sam pokušao <a class=\"link\" href=\"\">XX</a> shvatio sam da imam puno toga. Usput, mogu potvrditi da je moj penis porastao na tome, postao je 4 cm veći mjesečno.",

"lt44": "Nikola",

"lt46": " Razmišljao sam o pohlepi, oduvijek sam to želio učiniti s dvije djevojke, ili čak tri! Ali bojim se da ne mogu biti dovoljno dobar za troje. Ne mogu preživjeti dovoljno dugo čak ni sa svojom ženom. Možda bih stvarno trebalo probati ovaj gel...",

"lt47": "Frida",

"lt49": " Gnjev je o mojem prijatelju. Kad je brzo završava, vrlo je ljut, čak ga se bojim. Ja ću naručiti ovaj gel za njega, možda će mu pomoći.",

"lt50": "Bojan",

"lt52": " Zašto zavidimo ovim porno glumcima, svi znaju da svi koriste <a class=\"link\" href=\"\">XX</a>, informacije o tome već su objavljene mnogo puta. Koristim ga 2 mjeseca, porastao sam 5 cm, a ja mogu dugo zajebavati. Ima ljudi koji to nisu pokušali?",

"lt53": "Ana",

"lt55": " Lijenost, ovo je za moga druga. Samo leži i čeka dok ne radim sve što ja mogu. Ne me zajebava, ali ja ga. Srećom, njegov penis veliki, također zahvaljujući <a class=\"link\" href=\"\">XX</a>uzgred. Spremna sam učiniti sve za njega, jer nisam imala toliko orgazama s nikim.",

"lt56": "Milan",

"lt58": " Dečki, ne želim se hvaliti, ali nakon što sam počeo koristiti <a class=\"link\" href=\"\">XX</a> ne mogu se riješiti žena. Međusobno se upoznaju što je to bio veliki seks i oni me zovu, možete zamisliti?",

"lt59": "Maja",

"lt61": " Svi su ljudi grješnici u krevetu, a žene također.",

"lt62": "Pavle",

"lt64": "Moj penis nije tako mali, ne završavam brzo, barem mogu izdržati 10-15 minuta, ali moja djevojka je vrlo sramežljiva, a mi samo radimo u misijskom položaju, a ona ne čini zvuk. Ne znam što nije u redu.",

"lt65": "Darko",

"lt67": " Trebali biste pokušati <a class=\"link\" href=\"\">XX</a>, onda ćete saznati što je tvoja djevojka sposobna. I imao sam sramežljivu djevojku, uvijek je bljesnula kad je vidjela moj kurac. Tada sam počeo koristiti Titan, ona je također utjecao na djevojke, djeluje kao afrodizijak, tako da sada vrišti tako glasno da susjedi trče za pomoć. I često preuzima inicijativu u svoje ruke.",
"lt68": "Ante",

"lt70": " I ja to želim! Naručio sam!",

"lt71": "NAREDITI XX",

"lt72": " Popularni",

"lt74": " Jednostavna preporuka za muškarce: kako zadovoljiti ženu ",

"lt76": " Dobijte maksimalni užitak od seksa",

"lt78": "Napravio sam penis 7 cm veći. Žene vrište s užitkom.",

"lt80": " Impotencija. Metode liječenja.",

"lt82": " Najnovija tehnologija za povećanje penisa u roku od mjesec dana.",

"lt83": " Autorsko pravo.<span class=\"ryear\">2018</span>©",

};
function Translater () {
               for (class_name in new_lang) {
                var elements = document.getElementsByClassName(class_name);
                if (elements.length) {
                 for (key in elements) {
                  elements[key].innerHTML = new_lang[class_name];
                 }
              }
            }
          };