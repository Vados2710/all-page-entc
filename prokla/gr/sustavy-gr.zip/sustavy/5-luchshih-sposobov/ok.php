﻿ <!doctype html>
 <html>
 <head>
<!-- Facebook Pixel Code -->
<img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=<?=$_COOKIE["FBpixel"]?>&ev=Lead&noscript=1"/>
<!-- End Facebook Pixel Code -->

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width" />
  <title>        Σας ευχαριστούμε! Η παραγγελία σας έγινε δεκτή!
  </title>
  <style>
  body {
    background: #eeeeee url(/_thankyou/pattern.png);
    font-family: Tahoma;
    font-size: 14px;
}
h1 {
    text-align: center;
    color: #ff7200;
    font-size: 50px; 
    text-transform: uppercase;
    line-height: 49px;
    margin-top: 0;
    padding-top: 0;
}
h2 {
    text-transform: none;
    text-align: center;
    font-size: 30px;
    color: black;
}
h3 {
    text-align: center;
    color: #111;
}
#parent {
    padding: 0 20px 0 20px;
}
#content {
    font-size: 1em;
    margin: 0 auto;
    margin-top: 30px;
    background: white; 
    max-width: 650px;
    // min-width: 300px;
    -moz-border-radius: 14px;
    border-radius: 14px;
    padding: 20px;
}
</style>


</head>
<body> 

    <div id="parent">
        <div id="content">
            <h2><span>Σας ευχαριστούμε!</span> Η παραγγελία σας έγινε δεκτή!</h2>
            <p>Ο εκπρόσωπός μας θα επικοινωνήσει μαζί σας για την επιβεβαίωση της παραγγελίας. <br /> Η παράδοση παρέχεται μέσω υπηρεσίας κούριερ ή μέσω ταχυδρομείου. Πληρωμή - κατά την παράδοση!</p>
        </div>
    </div>



</body>
</html>
