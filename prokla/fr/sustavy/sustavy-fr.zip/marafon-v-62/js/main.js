$(document).ready(function () {
    $('.cenz-image').on('click', function () {
        $('.cenz-image').addClass('cenz-show');
        $('.cenz-image').css('background-image', 'none');
    });


});
